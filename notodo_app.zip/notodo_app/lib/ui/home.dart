import 'package:flutter/material.dart';

import 'notodo_screen.dart';
class Home extends StatelessWidget {
  Home(String s);

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: new AppBar(
        title: Text("notodo"),

        backgroundColor: Colors.black,
      ),

        body: new NotoDoScreen(),
    );
  }
}
